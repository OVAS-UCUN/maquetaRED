# maquetaRED
Repositorio para maquetación de vistas del recurso educativo digital seleccionado de las propuestas presentadas.
